// app.js
App({
  onLaunch() {
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        console.log(res.code);
        wx.request({
          url: '',
          method: 'POST',
          date: {
            code: res.code
          },
          success: res => {
            // console.log(res.data.token);
            this.globalData.token = res.data.token;
            wx.setStorage({
              key: 'token',
              data: res.data.token
            })
          },
          fall: res=> {
            console.log("Error")
          }
        })

      },
      fall: res=>{
        console.log("登陆失败")

      }
    })
  },
  globalData: {
    userInfo: null,
    token: null, //保存token
  }
})