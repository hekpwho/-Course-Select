// pages/index1/mycourse/mycourse.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list_c: [], // //已选的课程
    imageURL: "/images/3.jpg", //课程卡片上的图片

  },


  select: function (e) {
    console.log(e.currentTarget.dataset.index) //获取当前点击的index值
    let index = e.currentTarget.dataset.index
    var  that=this
    wx.showModal({
      title: '是否退选 ' + this.data.list_c[index].cname,
      content: '',
      complete: (res) => {
        if (res.confirm) {
          wx.request({ //点击确认后将sid和con发送到后台
            url: 'http://localhost:8080/auth/delSC',
            method: "POST",
            header: {
              'contet-type': 'application/json'
            },
            data: {
              sid: wx.getStorageSync('sid'),
              con: this.data.list_c[index].con,
            }, //传送json包到后台查询
            success: function (res) {
              console.log(res.data)
              if (res.data > 0)  //成功退课
               { wx.showToast({
                  title: '退课成功',
                });
                that.onLoad(); //重新加载页面
              }   
              else  {
                wx.showToast({
                  title: '退课失败',
                });
              }      
            }    
            
          })       
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    //从后端获取已经选过的课程信息
    var that = this;
    wx.request({
      url: 'http://127.0.0.1:8080/auth/getMycou',
      method: 'POST',
      header: {
        'contet-type': 'application/json'
      },
      data: {
        sid: wx.getStorageSync('sid')
      },
      success: function (res) {
        console.log(res.data);
        if (res.data) {
          that.setData({
            list_c: res.data
          });
        }
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})