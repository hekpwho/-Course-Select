// pages/index1/index1.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sid: '',
    sname: '',
    sex: '',
    sage: '',
    sdept: '',

    active: 2, //tab的值
    list: [
      "../shouye/shouye",
      "../search/search",
      "../setting/setting"
    ]
  },

  onChange(event) {
    wx.redirectTo({
      url: this.data.list[event.detail],
    })
    // event.detail 的值为当前选中项的索引
    this.setData({
      active: event.detail
    });


  },

  //退出登录按钮
  loginout: function (e) {
    wx.showModal({
      title: '确认退出',
      success(res) {
        if (res.confirm) {
          setTimeout(function () {
            wx.setStorageSync('sid', '') //清空本地保存的sid
            wx.reLaunch({
              url: '../../login/login', //跳转首页
            })
          }, 1000)

        }
      }
    })
  },
  mycourse:function(){
    wx.navigateTo({  
      //    navigateTo是为了适配下一个页面的返回按钮·
     
      url: '../mycourse/mycourse',
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    wx: wx.request({
      url: 'http://localhost:8080/auth/findStu',
      data: {
        sid: wx.getStorageSync('sid')
      },
      header: {
        'contet-type': 'application/json'
      },
      method: "POST",
      success: (result) => {
        this.setData({
          sid: result.data[0].sid,
          sname: result.data[0].sname,
          sex: result.data[0].sex,
          sage: result.data[0].sage,
          sdept: result.data[0].sdept

        })
        console.log()
      },
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {




  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})