// pages/index1/index1.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list_c: [], //保存从数据库取来的课程信息，渲染到前台

    imageURL: "/images/3.jpg", //课程卡片上的图片
    active: 0, //tab的值
    list: [
      "../shouye/shouye",
      "../search/search",
      "../setting/setting"
    ]
  },
  onChange(event) {
    wx.redirectTo({
      url: this.data.list[event.detail],
    })
    // event.detail 的值为当前选中项的索引
    this.setData({
      active: event.detail
    });

  },



  select: function (e) {
    console.log(e.currentTarget.dataset.index) //获取当前点击的index值
    let index = e.currentTarget.dataset.index
    var that = this
    wx.showModal({
      title: '是否选择 ' + this.data.list_c[index].cname,
      content: '',
      complete: (res) => {
        if (res.confirm) {
          wx.request({ //点击确认后将sid和con发送到后台
            url: 'http://localhost:8080/auth/inseSC',
            method: "POST",
            header: {
              'contet-type': 'application/json'
            },
            data: {
              sid: wx.getStorageSync('sid'),
              con: this.data.list_c[index].con,
            }, //传送json包到后台查询
            success: function (res) {
              if (res.data > 0) //成功选课
              {
                wx.showToast({
                  title: '选课成功',
                });
                that.onLoad(); //重新加载页面，为了更新cnum


              } else if (res.data == -1) {
                wx.showToast({
                  title: '已经选过了(￣▽￣)"',
                });
              } else wx.showToast({
                icon: "error",
                title: '选课失败',
              });
            }

          })
        }
      }
    })


  },




  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    //从后端获取课程信息  获取逻辑是获得cnum>0的课程
    var that = this;
    wx.request({
      url: 'http://127.0.0.1:8080/auth/reCour',
      method: 'GET',
      data:{
        sid:wx.getStorageSync("sid")
      },
      
      success: function (res) {
     
        if (res.data) {
          console.log(res.data)
          that.setData({
            list_c: res.data
          });
        }

      }
    })





  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {




  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})