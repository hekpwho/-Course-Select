// pages/index1/index1.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list_c: [], //保存课程
    imageURL: "/images/3.jpg", //课程卡片上的图片
    active: 1, //tab的值
    list: [
      "../shouye/shouye",
      "../search/search",   
      "../setting/setting"
    ],

    option1: [
      { text: '周一', value: '周一' },
      { text: '周二', value: '周二'},
      { text: '周三', value: '周三' },
      { text: '周四', value: '周四' },
      { text: '周五', value: '周五' },
      { text: '周六', value: '周六' },
      { text: '周日', value: '周日' },
    ],
    option2: [
      { text: '12', value: '12' },
      { text: '34', value: '34' },
      { text: '56', value: '56' },
      { text: '78', value: '78' },
    ],
    value1: '周一',
    value2: '12',
  },

  //下拉菜单点击事件
  handleChage1(e){
    this.setData({value1:e.detail})
    this.onLoad()   //更改value1再重新加载页面
 },
 handleChage2(e){
  this.setData({value2:e.detail})
  this.onLoad()
},

  
  onChange(event) {
    wx.redirectTo({
      url: this.data.list[event.detail],
    })
    // event.detail 的值为当前选中项的索引
    this.setData({
      active: event.detail
    });
  },

  select: function (e) {
    console.log(e.currentTarget.dataset.index) //获取当前点击的index值
    let index = e.currentTarget.dataset.index
    var  that=this
    wx.showModal({
      title: '是否选择 ' + this.data.list_c[index].cname,
      content: '',
      complete: (res) => {
        if (res.confirm) {
          wx.request({ //点击确认后将sid和con发送到后台
            url: 'http://localhost:8080/auth/inseSC',
            method: "POST",
            header: {
              'contet-type': 'application/json'
            },
            data: {
              sid: wx.getStorageSync('sid'),
              con: this.data.list_c[index].con,
            }, //传送json包到后台查询
            success: function (res) {
              if (res.data > 0)  //成功选课
               { wx.showToast({
                  title: '选课成功',
                });
                that.onLoad(); //重新加载页面
              }   
              else if(res.data==-1) {
                wx.showToast({
                  title: '已经选过了(￣▽￣)"',
                });
              }      
              else  wx.showToast({
                icon: "error",
                title: '选课失败',
              });
            }    
            
          })       
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

    //从后端获取课程信息
    var that = this;
    wx.request({
      url: 'http://127.0.0.1:8080/auth/seaCour',
      method: 'POST',
      header: {
        'contet-type': 'application/json'
      },
      data: {
        value: that.data.value1+that.data.value2,
        sid: wx.getStorageSync('sid')
      },
      success: function (res) {
         console.log(res.data);
        if (res.data) {
         
          that.setData({
       list_c: res.data
          });
        }

      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {




  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

    

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})