// pages/login/login.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sid: '',
    spwd: ''

  },

  getsid: function (e) {
    let value = e.detail.value; //获取input框的内容
    this.setData({
      sid: value
    })
    wx.setStorageSync('sid', value); //本地存入sid
  },

  getspwd: function (e) {
    let value = e.detail.value; //获取input框的内容
    this.setData({
      spwd: value
    })
    wx.setStorageSync('spwd', value)
  },

  login: function (e) {
    if (this.data.sid == 0 || this.data.spwd.length == 0) {
      wx.showToast({
        icon: 'none',
        title: '用户名或密码不能为空',
      })
    } else {
      wx.request({
        url: 'http://127.0.0.1:8080/auth',
        method: 'post',
        header: {
          'contet-type': 'application/json'
        },
        data: {
          sid: this.data.sid,
          spwd: this.data.spwd,
        }, //传送json包到后台查询
        success: function (res) {
          if (res.data.length>0) {
            console.log(res.data)
            wx.showToast({
              title: '登录成功',
            });
            console.log(res.data);
            setTimeout(function () {
              wx.redirectTo({
                url: '../index1/shouye/shouye', //跳转首页
              })
            }, 1000)

          } else {
            wx.showToast({
              icon: 'none',
              title: '学号或密码错误',
            })
          }
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    wx.request({
      url: 'http://127.0.0.1:8080/auth',
      method: 'post',
      header: {
        'contet-type': 'application/json'
      },
      data: {
        sid: wx.getStorageSync('sid'),  //加载时尝试使用本地保存的sid
        spwd: wx.getStorageSync('spwd'),
      },
      success: function (res) {
        if (res.data.length>0) {
          console.log(res.data);
          wx.showToast({
            title: '加载成功',
          });
         
          wx.redirectTo({
            url: '../index1/shouye/shouye',
          })

        }

      }



    })



  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})